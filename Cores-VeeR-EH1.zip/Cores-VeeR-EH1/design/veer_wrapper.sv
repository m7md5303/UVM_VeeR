// SPDX-License-Identifier: Apache-2.0
// Copyright 2019 Western Digital Corporation or its affiliates.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//********************************************************************************
// $Id$
//
// Function: Top wrapper file with veer/mem instantiated inside
// Comments:
//
//********************************************************************************
`define ASSERT_MODE
//`include "def.sv"
module veer_wrapper
   import veer_types::*;
(
   input logic                       clk,
   input logic                       rst_l,
   input logic                       dbg_rst_l, 
   input logic [31:1]                rst_vec,
   input logic                       nmi_int,
   input logic [31:1]                nmi_vec,
   input logic [31:1]                jtag_id,


   output logic [63:0] trace_rv_i_insn_ip,
   output logic [63:0] trace_rv_i_address_ip,
   output logic [2:0]  trace_rv_i_valid_ip,
   output logic [2:0]  trace_rv_i_exception_ip,
   output logic [4:0]  trace_rv_i_ecause_ip,
   output logic [2:0]  trace_rv_i_interrupt_ip,
   output logic [31:0] trace_rv_i_tval_ip,

   // Bus signals

`ifdef RV_BUILD_AXI4
   //-------------------------- LSU AXI signals--------------------------
   // AXI Write Channels
   output logic                            lsu_axi_awvalid,
   input  logic                            lsu_axi_awready,
   output logic [`RV_LSU_BUS_TAG-1:0]      lsu_axi_awid,
   output logic [31:0]                     lsu_axi_awaddr,
   output logic [3:0]                      lsu_axi_awregion,
   output logic [7:0]                      lsu_axi_awlen,
   output logic [2:0]                      lsu_axi_awsize,
   output logic [1:0]                      lsu_axi_awburst,
   output logic                            lsu_axi_awlock,
   output logic [3:0]                      lsu_axi_awcache,
   output logic [2:0]                      lsu_axi_awprot,
   output logic [3:0]                      lsu_axi_awqos,

   output logic                            lsu_axi_wvalid,
   input  logic                            lsu_axi_wready,
   output logic [63:0]                     lsu_axi_wdata,
   output logic [7:0]                      lsu_axi_wstrb,
   output logic                            lsu_axi_wlast,

   input  logic                            lsu_axi_bvalid,
   output logic                            lsu_axi_bready,
   input  logic [1:0]                      lsu_axi_bresp,
   input  logic [`RV_LSU_BUS_TAG-1:0]      lsu_axi_bid,

   // AXI Read Channels 
   output logic                            lsu_axi_arvalid,
   input  logic                            lsu_axi_arready,
   output logic [`RV_LSU_BUS_TAG-1:0]      lsu_axi_arid,
   output logic [31:0]                     lsu_axi_araddr,
   output logic [3:0]                      lsu_axi_arregion,
   output logic [7:0]                      lsu_axi_arlen,
   output logic [2:0]                      lsu_axi_arsize,
   output logic [1:0]                      lsu_axi_arburst,
   output logic                            lsu_axi_arlock,
   output logic [3:0]                      lsu_axi_arcache,
   output logic [2:0]                      lsu_axi_arprot,
   output logic [3:0]                      lsu_axi_arqos,

   input  logic                            lsu_axi_rvalid,
   output logic                            lsu_axi_rready,
   input  logic [`RV_LSU_BUS_TAG-1:0]      lsu_axi_rid,
   input  logic [63:0]                     lsu_axi_rdata,
   input  logic [1:0]                      lsu_axi_rresp,
   input  logic                            lsu_axi_rlast,

   //-------------------------- IFU AXI signals--------------------------
   // AXI Write Channels
   output logic                            ifu_axi_awvalid,
   input  logic                            ifu_axi_awready,
   output logic [`RV_IFU_BUS_TAG-1:0]      ifu_axi_awid,
   output logic [31:0]                     ifu_axi_awaddr,
   output logic [3:0]                      ifu_axi_awregion,
   output logic [7:0]                      ifu_axi_awlen,
   output logic [2:0]                      ifu_axi_awsize,
   output logic [1:0]                      ifu_axi_awburst,
   output logic                            ifu_axi_awlock,
   output logic [3:0]                      ifu_axi_awcache,
   output logic [2:0]                      ifu_axi_awprot,
   output logic [3:0]                      ifu_axi_awqos,

   output logic                            ifu_axi_wvalid,
   input  logic                            ifu_axi_wready,
   output logic [63:0]                     ifu_axi_wdata,
   output logic [7:0]                      ifu_axi_wstrb,
   output logic                            ifu_axi_wlast,

   input  logic                            ifu_axi_bvalid,
   output logic                            ifu_axi_bready,
   input  logic [1:0]                      ifu_axi_bresp,
   input  logic [`RV_IFU_BUS_TAG-1:0]      ifu_axi_bid,

   // AXI Read Channels
   output logic                            ifu_axi_arvalid,
   input  logic                            ifu_axi_arready,
   output logic [`RV_IFU_BUS_TAG-1:0]      ifu_axi_arid,
   output logic [31:0]                     ifu_axi_araddr,
   output logic [3:0]                      ifu_axi_arregion,
   output logic [7:0]                      ifu_axi_arlen,
   output logic [2:0]                      ifu_axi_arsize,
   output logic [1:0]                      ifu_axi_arburst,
   output logic                            ifu_axi_arlock,
   output logic [3:0]                      ifu_axi_arcache,
   output logic [2:0]                      ifu_axi_arprot,
   output logic [3:0]                      ifu_axi_arqos,

   input  logic                            ifu_axi_rvalid,
   output logic                            ifu_axi_rready,
   input  logic [`RV_IFU_BUS_TAG-1:0]      ifu_axi_rid,
   input  logic [63:0]                     ifu_axi_rdata,
   input  logic [1:0]                      ifu_axi_rresp,
   input  logic                            ifu_axi_rlast,

   //-------------------------- SB AXI signals--------------------------
   // AXI Write Channels
   output logic                            sb_axi_awvalid,
   input  logic                            sb_axi_awready,
   output logic [`RV_SB_BUS_TAG-1:0]       sb_axi_awid,
   output logic [31:0]                     sb_axi_awaddr,
   output logic [3:0]                      sb_axi_awregion,
   output logic [7:0]                      sb_axi_awlen,
   output logic [2:0]                      sb_axi_awsize,
   output logic [1:0]                      sb_axi_awburst,
   output logic                            sb_axi_awlock,
   output logic [3:0]                      sb_axi_awcache,
   output logic [2:0]                      sb_axi_awprot,
   output logic [3:0]                      sb_axi_awqos,

   output logic                            sb_axi_wvalid,
   input  logic                            sb_axi_wready,
   output logic [63:0]                     sb_axi_wdata,
   output logic [7:0]                      sb_axi_wstrb,
   output logic                            sb_axi_wlast,

   input  logic                            sb_axi_bvalid,
   output logic                            sb_axi_bready,
   input  logic [1:0]                      sb_axi_bresp,
   input  logic [`RV_SB_BUS_TAG-1:0]       sb_axi_bid,

   // AXI Read Channels
   output logic                            sb_axi_arvalid,
   input  logic                            sb_axi_arready,
   output logic [`RV_SB_BUS_TAG-1:0]       sb_axi_arid,
   output logic [31:0]                     sb_axi_araddr,
   output logic [3:0]                      sb_axi_arregion,
   output logic [7:0]                      sb_axi_arlen,
   output logic [2:0]                      sb_axi_arsize,
   output logic [1:0]                      sb_axi_arburst,
   output logic                            sb_axi_arlock,
   output logic [3:0]                      sb_axi_arcache,
   output logic [2:0]                      sb_axi_arprot,
   output logic [3:0]                      sb_axi_arqos,

   input  logic                            sb_axi_rvalid,
   output logic                            sb_axi_rready,
   input  logic [`RV_SB_BUS_TAG-1:0]       sb_axi_rid,
   input  logic [63:0]                     sb_axi_rdata,
   input  logic [1:0]                      sb_axi_rresp,
   input  logic                            sb_axi_rlast,

   //-------------------------- DMA AXI signals--------------------------
   // AXI Write Channels
   input  logic                         dma_axi_awvalid,
   output logic                         dma_axi_awready,
   input  logic [`RV_DMA_BUS_TAG-1:0]   dma_axi_awid,
   input  logic [31:0]                  dma_axi_awaddr,
   input  logic [2:0]                   dma_axi_awsize,
   input  logic [2:0]                   dma_axi_awprot,
   input  logic [7:0]                   dma_axi_awlen,
   input  logic [1:0]                   dma_axi_awburst,


   input  logic                         dma_axi_wvalid,
   output logic                         dma_axi_wready,
   input  logic [63:0]                  dma_axi_wdata,
   input  logic [7:0]                   dma_axi_wstrb,
   input  logic                         dma_axi_wlast,

   output logic                         dma_axi_bvalid,
   input  logic                         dma_axi_bready,
   output logic [1:0]                   dma_axi_bresp,
   output logic [`RV_DMA_BUS_TAG-1:0]   dma_axi_bid,

   // AXI Read Channels
   input  logic                         dma_axi_arvalid,
   output logic                         dma_axi_arready,
   input  logic [`RV_DMA_BUS_TAG-1:0]   dma_axi_arid,
   input  logic [31:0]                  dma_axi_araddr,
   input  logic [2:0]                   dma_axi_arsize,
   input  logic [2:0]                   dma_axi_arprot,
   input  logic [7:0]                   dma_axi_arlen,
   input  logic [1:0]                   dma_axi_arburst,

   output logic                         dma_axi_rvalid,
   input  logic                         dma_axi_rready,
   output logic [`RV_DMA_BUS_TAG-1:0]   dma_axi_rid,
   output logic [63:0]                  dma_axi_rdata,
   output logic [1:0]                   dma_axi_rresp,
   output logic                         dma_axi_rlast,

`endif

   // clk ratio signals
   input logic                       lsu_bus_clk_en, // Clock ratio b/w cpu core clk & AHB master interface
   input logic                       ifu_bus_clk_en, // Clock ratio b/w cpu core clk & AHB master interface
   input logic                       dbg_bus_clk_en, // Clock ratio b/w cpu core clk & AHB master interface
   input logic                       dma_bus_clk_en, // Clock ratio b/w cpu core clk & AHB slave interface


//   input logic                   ext_int,
   input logic                       timer_int,
   input logic [`RV_PIC_TOTAL_INT:1] extintsrc_req,

   output logic [1:0] dec_tlu_perfcnt0, // toggles when perf counter 0 has an event inc
   output logic [1:0] dec_tlu_perfcnt1,
   output logic [1:0] dec_tlu_perfcnt2,
   output logic [1:0] dec_tlu_perfcnt3,

   // ports added by the soc team
   input logic                       jtag_tck, // JTAG clk
   input logic                       jtag_tms, // JTAG TMS
   input logic                       jtag_tdi, // JTAG tdi
   input logic                       jtag_trst_n, // JTAG Reset
   output logic                      jtag_tdo, // JTAG TDO
   // external MPC halt/run interface
   input logic mpc_debug_halt_req, // Async halt request
   input logic mpc_debug_run_req, // Async run request
   input logic mpc_reset_run_req, // Run/halt after reset
   output logic mpc_debug_halt_ack, // Halt ack
   output logic mpc_debug_run_ack, // Run ack
   output logic debug_brkpt_status, // debug breakpoint

   input logic                       i_cpu_halt_req, // Async halt req to CPU
   output logic                      o_cpu_halt_ack, // core response to halt
   output logic                      o_cpu_halt_status, // 1'b1 indicates core is halted
   output logic                      o_debug_mode_status, // Core to the PMU that core is in debug mode. When core is in debug mode, the PMU should refrain from sendng a halt or run request
   input logic                       i_cpu_run_req, // Async restart req to CPU
   output logic                      o_cpu_run_ack, // Core response to run req
   input logic                       scan_mode, // To enable scan mode
   input logic                       mbist_mode // to enable mbist
);

`include "global.vh"

   // DCCM ports
   logic         dccm_wren;
   logic         dccm_rden;
   logic [DCCM_BITS-1:0]  dccm_wr_addr;
   logic [DCCM_BITS-1:0]  dccm_rd_addr_lo;
   logic [DCCM_BITS-1:0]  dccm_rd_addr_hi;
   logic [DCCM_FDATA_WIDTH-1:0]  dccm_wr_data;

   logic [DCCM_FDATA_WIDTH-1:0]  dccm_rd_data_lo;
   logic [DCCM_FDATA_WIDTH-1:0]  dccm_rd_data_hi;

   logic         lsu_freeze_dc3;

   // PIC ports

   // Icache & Itag ports
   logic [31:2]  ic_rw_addr;
   logic [3:0]   ic_wr_en  ;     // Which way to write
   logic         ic_rd_en ;


   logic [3:0]   ic_tag_valid;   // Valid from the I$ tag valid outside (in flops).

   logic [3:0]   ic_rd_hit;      // ic_rd_hit[3:0]
   logic         ic_tag_perr;    // Ic tag parity error

   logic [15:2]  ic_debug_addr;      // Read/Write addresss to the Icache.
   logic         ic_debug_rd_en;     // Icache debug rd
   logic         ic_debug_wr_en;     // Icache debug wr
   logic         ic_debug_tag_array; // Debug tag array
   logic [3:0]   ic_debug_way;       // Debug way. Rd or Wr.

`ifdef RV_ICACHE_ECC
   logic [24:0]  ictag_debug_rd_data;// Debug icache tag.
   logic [83:0]  ic_wr_data;         // ic_wr_data[135:0]
   logic [167:0] ic_rd_data;         // ic_rd_data[135:0]
   logic [41:0]  ic_debug_wr_data;   // Debug wr cache.
`else
   logic [20:0]  ictag_debug_rd_data;// Debug icache tag.
   logic [67:0]  ic_wr_data;         // ic_wr_data[135:0]
   logic [135:0] ic_rd_data;         // ic_rd_data[135:0]
   logic [33:0]  ic_debug_wr_data;   // Debug wr cache.
`endif

   logic [127:0] ic_premux_data;
   logic         ic_sel_premux_data;

`ifdef RV_ICCM_ENABLE
   // ICCM ports
   logic [`RV_ICCM_BITS-1:2]    iccm_rw_addr;
   logic           iccm_wren;
   logic           iccm_rden;
   logic [2:0]     iccm_wr_size;
   logic [77:0]    iccm_wr_data;
   logic [155:0]   iccm_rd_data;
`endif

   logic        core_rst_l;     // Core reset including rst_l and dbg_rst_l
   logic        jtag_tdoEn;

   logic        dccm_clk_override;
   logic        icm_clk_override;
   logic        dec_tlu_core_ecc_disable;

   logic        dmi_reg_en;
   logic [6:0]  dmi_reg_addr;
   logic        dmi_reg_wr_en;
   logic [31:0] dmi_reg_wdata;
   logic [31:0] dmi_reg_rdata;
   logic        dmi_hard_reset;


   // Instantiate the veer core
   veer veer (
          .*
          );

   // Instantiate the mem 
   mem  mem (
        .rst_l(core_rst_l),
        .*
        );

  // Instantiate the JTAG/DMI
   dmi_wrapper  dmi_wrapper (
           // JTAG signals
           .trst_n(jtag_trst_n),           // JTAG reset
           .tck   (jtag_tck),              // JTAG clock
           .tms   (jtag_tms),              // Test mode select
           .tdi   (jtag_tdi),              // Test Data Input
           .tdo   (jtag_tdo),              // Test Data Output
           .tdoEnable (),                  // Test Data Output enable

           // Processor Signals
           .core_rst_n  (dbg_rst_l),     // Primary reset, active low
           .core_clk    (clk),            // Core clock
           .jtag_id     (jtag_id),        // 32 bit JTAG ID
           .rd_data     (dmi_reg_rdata),  // 32 bit Read data from  Processor
           .reg_wr_data (dmi_reg_wdata),  // 32 bit Write data to Processor
           .reg_wr_addr (dmi_reg_addr),   // 32 bit Write address to Processor
           .reg_en      (dmi_reg_en),     // 1 bit  Write interface bit to Processor
           .reg_wr_en   (dmi_reg_wr_en),   // 1 bit  Write enable to Processor
           .dmi_hard_reset   (dmi_hard_reset)   //a hard reset of the DTM, causing the DTM to forget about any outstanding DMI transactions
   );


   `ifdef ASSERT_MODE
   //reset
      always_comb begin
         if(!rst_l) begin
         async_reset: begin 
                      assert final(trace_rv_i_valid_ip == 0);
                      assert final(lsu_axi_awvalid == 0);
                      assert final(lsu_axi_wvalid == 0);
                      assert final(lsu_axi_bready == 0);
                      assert final(lsu_axi_arvalid == 0);
                      assert final(lsu_axi_rready == 0);
                      assert final(ifu_axi_awvalid == 0);
                      assert final(ifu_axi_wvalid == 0);
                      assert final(ifu_axi_bready == 0);
                      assert final(ifu_axi_arvalid == 0);
                      assert final(ifu_axi_rready == 0);
                      assert final(sb_axi_awvalid == 0);
                      assert final(sb_axi_wvalid == 0);
                      assert final(sb_axi_bready == 0);
                      assert final(sb_axi_arvalid == 0);
                      assert final(sb_axi_rready == 0);
                      assert final(dma_axi_awready == 0);
                      assert final(dma_axi_wready == 0);
                      assert final(dma_axi_bvalid == 0);
                      assert final(dma_axi_arready == 0);
                      assert final(dma_axi_rvalid == 0);
                     end
         end
         if(!jtag_trst_n) begin
            jtag_reset: assert final(jtag_tdo == 0);
         end
      end
   //restart
      property cpu_restart;
         @(posedge clk) disable iff(!rst_l) ($rose(i_cpu_run_req)&&!i_cpu_halt_req) |=> $rose(o_cpu_run_ack);
      endproperty
      cprst: assert property (cpu_restart) else $display("failed to get restart after halt ack at time %0t",$time);
      cprstcv: cover property (cpu_restart);

      property mpc_restart;
         @(posedge clk) disable iff(!rst_l) ($rose(mpc_debug_run_req)&&!mpc_debug_halt_req) |=> $rose(mpc_debug_run_ack);
      endproperty
      cprst_mpc: assert property (mpc_restart) else $display("failed to get mpc restart after halt ack at time %0t",$time);
      cprstcv_mpc: cover property (mpc_restart);
   //axi_lsu
      property axi_lsu_len;
         @(posedge clk) disable iff(!rst_l) (lsu_axi_awvalid&&lsu_axi_awready) |=> (lsu_axi_wlast&&lsu_axi_wvalid) [->1];
      endproperty
      last_lsu: assert property (axi_lsu_len) else $display ("hanged write transaction; last wasn't asserted");
      last_lsu_cp: cover property (axi_lsu_len);

      property axi_cont_lsu;
         @(posedge clk) disable iff(!rst_l) (lsu_axi_awready&&lsu_axi_awvalid) |=> (lsu_axi_wready&&lsu_axi_wvalid) [->1];
      endproperty
      wr_axi_lsu: assert property (axi_cont_lsu) else $display("handshake without data sent false frame at time %0t",$time);
      wr_axi_lsucp: cover property (axi_cont_lsu);

      property axi_cont_lsur;
         @(posedge clk) disable iff(!rst_l) (lsu_axi_arready&&lsu_axi_arvalid) |=> (lsu_axi_rready&&lsu_axi_rvalid) [->1];
      endproperty
      rd_axi_lsu: assert property (axi_cont_lsur) else $display("handshake without data received false frame at time %0t",$time);
      rd_axi_lsucp: cover property (axi_cont_lsur);

   //axi_ifu
      property axi_ifu_len;
         @(posedge clk) disable iff(!rst_l) (ifu_axi_awvalid&&ifu_axi_awready) |=> (ifu_axi_wlast&&ifu_axi_wvalid) [->1];
      endproperty
      last_ifu: assert property (axi_ifu_len) else $display ("hanged write transaction; last wasn't asserted");
      last_ifu_cp: cover property (axi_ifu_len);

      property axi_cont_ifu;
         @(posedge clk) disable iff(!rst_l) (ifu_axi_awready&&ifu_axi_awvalid) |=> (ifu_axi_wready&&ifu_axi_wvalid) [->1];
      endproperty
      wr_axi_ifu: assert property (axi_cont_ifu) else $display("handshake without data sent false frame at time %0t",$time);
      wr_axi_ifucp: cover property (axi_cont_ifu);

      property axi_cont_ifur;
         @(posedge clk) disable iff(!rst_l) (ifu_axi_arready&&ifu_axi_arvalid) |=> (ifu_axi_rready&&ifu_axi_rvalid) [->1];
      endproperty
      rd_axi_ifu: assert property (axi_cont_ifur) else $display("handshake without data received false frame at time %0t",$time);
      rd_axi_ifucp: cover property (axi_cont_ifur);

   //axi_dbg
      property axi_sb_len;
         @(posedge clk) disable iff(!rst_l) (sb_axi_awvalid&&sb_axi_awready) |=> (sb_axi_wlast&&sb_axi_wvalid) [->1];
      endproperty
      last_sb: assert property (axi_sb_len) else $display ("hanged write transaction; last wasn't asserted");
      last_sb_cp: cover property (axi_sb_len);

      property axi_cont_sb;
         @(posedge clk) disable iff(!rst_l) (sb_axi_awready&&sb_axi_awvalid) |=> (sb_axi_wready&&sb_axi_wvalid) [->1];
      endproperty
      wr_axi_sb: assert property (axi_cont_sb) else $display("handshake without data sent false frame at time %0t",$time);
      wr_axi_sbcp: cover property (axi_cont_sb);

      property axi_cont_sbr;
         @(posedge clk) disable iff(!rst_l) (sb_axi_arready&&sb_axi_arvalid) |=> (sb_axi_rready&&sb_axi_rvalid) [->1];
      endproperty
      rd_axi_sb: assert property (axi_cont_sbr) else $display("handshake without data received false frame at time %0t",$time);
      rd_axi_sbcp: cover property (axi_cont_sbr);

   //axi_dma
      property wr_ready;
         @(posedge clk) disable iff(!rst_l) (dma_axi_awready&&dma_axi_awvalid) |=> dma_axi_wready [->1];
      endproperty
      wrrdy: assert property (wr_ready) else $display("the core didnt respond to a successful handshake at time %0t",$time);
      wrrdy_cp: cover property (wr_ready);

      property rd_valid;
         @(posedge clk) disable iff(!rst_l) (dma_axi_arready&&dma_axi_arvalid) |=> dma_axi_rvalid [->1];
      endproperty
      rvld: assert property (rd_valid) else $display("the core didnt respond to a successful read handshake at time %0t",$time);
      rvld_cp: cover property (rd_valid);

   `endif

endmodule

